
import ecs100.*;

public class WeightCalculator{
    
    public void printFormula ( ) {
        UI.println("1 pound = 0.4536 kg");
    }

    /** Ask for pounds and ounces and convert to kilos */
    public void doPoundsToKilos(){
        double pounds = UI.askDouble("Pounds:");
        double kilos = pounds * 0.4536;
        UI.println(pounds +  " lbs -> " + kilos + " kg");
        
    }

    /** Ask for kilos and convert to pounds and ounces */
    public void doKilosToPounds(){
        double kilos = UI.askDouble("kilos:");
        double pounds = kilos / 0.4536;
        UI.println(pounds +  " lbs -> " + kilos + " kg");
    }

}
