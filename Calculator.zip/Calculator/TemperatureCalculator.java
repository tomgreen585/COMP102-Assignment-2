import ecs100.*;

/** <description of class TemperatureCalculatorB>
 */
public class TemperatureCalculator{
    /** Print conversion formula */
    public void printFormula ( ) {
        UI.println("Celsius = (Fahrenheit - 32) *5/9");
    }

    /** Ask for Fahrenheit and convert to Celsius */
    public void doFahrenheitToCelsius(){
        double fahrenheit = UI.askDouble("Fahrenheit:");
        double celsius = (fahrenheit - 32.0) * 5.0 / 9.0;
        UI.println(fahrenheit +  " F -> " + celsius + " C");
    }

    public void setupGui(){
        UI.addButton("Formula", this::printFormula);
        UI.addButton("F -> C", this::doFahrenheitToCelsius);
        UI.addButton("Quit", UI::quit);
        
        UI.setDivider(1.0);
    }
}
