import ecs100.*;

/** <description of class TemperatureCalculatorB>
 */
public class TemperatureCalculator{
    /** Print conversion formula */
    public void printFormula ( ) {
        UI.println("Celsius = (Fahrenheit - 32) *5/9");
    }

    /** Ask for Fahrenheit and convert to Celsius */
    public void doFahrenheitToCelsius(){
        double fahrenheit = UI.askDouble("Fahrenheit:");

        if(fahrenheit>=-459.67) {
            double celsius = (fahrenheit - 32.0) * 5.0 / 9.0;
            UI.println(fahrenheit +  " F -> " + celsius + " C");
        } else {
            UI.println("The value is below the absolute zero (-459.67F)");
        }
    }

    public void setupGui(){
        UI.addButton("Formula", this::printFormula);
        UI.addButton("F -> C", this::doFahrenheitToCelsius);
        UI.addButton("Quit", UI::quit);

        UI.setDivider(1.0);
    }
}
