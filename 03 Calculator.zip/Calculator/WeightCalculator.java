
import ecs100.*;

public class WeightCalculator{

    public void printFormula ( ) {
        UI.println("1 pound = 0.4536 kg");
    }

    /** Ask for pounds and ounces and convert to kilos */
    public void doPoundsToKilos(){
        double pounds = UI.askDouble("Pounds:");

        if(pounds >= 0) {
            double kilos = pounds * 0.4536;
            UI.println(pounds +  " lbs -> " + kilos + " kg");
        } else {
            UI.println("You cannot have a negative weight.");
        }

    }

    /** Ask for kilos and convert to pounds and ounces */
    public void doKilosToPounds(){
        double kilos = UI.askDouble("kilos:");

        if(kilos >= 0) {        
            double pounds = kilos / 0.4536;
            UI.println(kilos +  " kg -> " + pounds + " lbs");
        } else {
            UI.println("You cannot have a negative weight.");
        }
    }

    public void teamInfo() {
        int size = UI.askInt("Team size");
        int weight = UI.askInt("Team weight");

        this.averageWeight(weight, size);
    }

    public void averageWeight(double weight, int teamSize) {
        if(teamSize != 0) {
            double averageWeight = weight / teamSize;
            UI.println(averageWeight);
        }

    }

}
