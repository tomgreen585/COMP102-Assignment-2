// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102/112 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP-102-112 - 2022T1, LabExercise 2
 * Name:
 * Username:
 * ID:
 */

import ecs100.*;
import java.awt.Color;

public class ConditionalsExercise{

    public static final double LEFT = 100; //position of shapes
    public static final double TOP = 100; 

    /**
     * Ask user for an integer
     * if the number is a valid hour (1 to 12), then it prints the number in
     * the form  "The time is 6 o'clock" (if they entered 6)
     * otherwise it prints  "That number is not a valid time"
     */
    public void validHour(){
        /*# YOUR CODE HERE */

    }

    /**
     * Asks the user to enter a word.
     * Says "Yes, that fits" if the word starts with "p" and is 7 characters long,
     * and "Sorry, that word won't work" otherwise.
     * You can use the length() method on a string to find out how long it it.
     */
    public void wordGame(){
        /*# YOUR CODE HERE */

    }

    /**
     * Asks the user to enter the name of a shape, and
     * draws the appropriate shape (by calling one of the
     * draw... methods below - you don't have to write them).
     * Recognises Cup, Man, Cat, Car and TV.
     * If the user enteres any other shape, it will say
     *  "Sorry, I don't know about that shape".
     */
    public void drawAShape(){
        /*# YOUR CODE HERE */

    }

    /** Asks the user to enter three words and prints out the longest one.
     * (if two words are equally long, it doesn't matter which it prints).
     * You can call the length() method on a string to find out how long it is.
     * Note that there are three possible cases to check for.
     */
    public void longestWord(){
        /*# YOUR CODE HERE */

    }

    /** ---------- The code below is already written for you ---------- **/
    // The methods called by drawAShape.
    /** Draw a cup */
    public void drawCup(){
        UI.clearGraphics();
        double height = 240.0;
        double width = height/1.5;
        double ovalHeight = height/5.0;
        double handleDiam = height/2.0;
        UI.setColor(Color.red);
        UI.fillOval(LEFT, TOP+height-ovalHeight/2, width, ovalHeight);
        UI.fillRect(LEFT, TOP, width, height);
        UI.setColor(Color.black);
        UI.fillOval(LEFT, TOP-ovalHeight/2, width, ovalHeight);
        UI.setLineWidth(15);
        UI.setColor(Color.red);
        UI.drawOval(LEFT+width-handleDiam/2,TOP+height/4.0,handleDiam,handleDiam);
        UI.resetLineWidth();
    }

    /** Draw a stick man roughly following the 8 heads rule */
    public void drawMan(){
        UI.clearGraphics();
        double height = 240.0;
        double headHeight = height/6;
        double eighthHeight = height/8.0;
        double bodyLine = LEFT + headHeight*2;
        double topChest = TOP + headHeight;
        double bodyHeight = height*3.0/8.0;
        UI.setColor(Color.black);
        UI.setLineWidth(2);
        UI.drawOval(bodyLine-headHeight/4.0, TOP, headHeight/2.0, headHeight);   // head
        UI.drawLine(bodyLine, topChest, bodyLine, TOP+height/2.0);               // body
        UI.drawLine(bodyLine-eighthHeight/2.0, topChest+height/32, bodyLine+eighthHeight/2.0, topChest+height/32);    // shoulders
        UI.drawLine(bodyLine-eighthHeight/2.0, topChest+height/32, LEFT, topChest-eighthHeight*3/5);                  // left arm
        UI.drawLine(bodyLine+eighthHeight/2.0, topChest+height/32, bodyLine+eighthHeight*2, TOP-eighthHeight*3/5);    // right arm
        UI.drawLine(bodyLine-eighthHeight/2.0, TOP+height/2, bodyLine+eighthHeight/2.0, TOP+height/2);                // hips
        UI.drawLine(bodyLine-eighthHeight/2.0, TOP+height/2, LEFT, TOP+height);                                       // left leg
        UI.drawLine(bodyLine+eighthHeight/2.0, TOP+height/2, bodyLine+eighthHeight*2, TOP+height);                    // right leg
        UI.resetLineWidth();
    }

    /** Draw a cat's head */
    public void drawCat(){
        UI.clearGraphics();
        double height = 200;
        UI.setLineWidth(5);

        // Draw head and ears outlines
        UI.setColor(Color.black);
        UI.drawOval(LEFT, TOP, height, height);
        UI.setColor(Color.white);
        UI.fillOval(LEFT+height*0.18, TOP-height*0.205, height*0.64, height*0.64);
        UI.setColor(Color.black);
        UI.drawLine(LEFT+height*0.18, TOP+height*0.115, LEFT+height*0.25, TOP+height/3);
        UI.drawLine(LEFT+height*0.82, TOP+height*0.115, LEFT+height*0.75, TOP+height/3);
        UI.drawLine(LEFT+height*0.25, TOP+height/3, LEFT+height*0.75, TOP+height/3);

        // Draw eyes
        UI.setColor(Color.green);
        double topHead= TOP+height/3.0;
        double eye = height/8;
        UI.fillOval(LEFT+height*0.19, topHead+height/6-eye/2, eye, eye);
        UI.fillOval(LEFT+height*0.69, topHead+height/6-eye/2, eye, eye);

        // Draw nose and mouth
        double nose = height/5;
        UI.setColor(Color.black);
        UI.fillOval(LEFT+height/2-nose/2, topHead+height/3-nose/2, nose, nose);
        UI.drawLine(LEFT+height/2-nose/2, topHead+height/2, LEFT+height/2+nose/2, topHead+height/2);
        UI.drawLine(LEFT+height/2, topHead+height/2, LEFT+height/2, topHead+height/3);

        // Draw left whiskers
        UI.drawLine(LEFT+height*0.3, topHead+height*0.35, LEFT-height*0.17, topHead+height*0.28);
        UI.drawLine(LEFT+height*0.25, topHead+height*0.39, LEFT-height*0.15, topHead+height*0.36);
        UI.drawLine(LEFT+height*0.28, topHead+height*0.43, LEFT-height*0.16, topHead+height*0.50);

        // Draw right whiskers
        UI.drawLine(LEFT+height*0.70, topHead+height*0.35, LEFT+height*1.17, topHead+height*0.28);
        UI.drawLine(LEFT+height*0.75, topHead+height*0.39, LEFT+height*1.15, topHead+height*0.36);
        UI.drawLine(LEFT+height*0.72, topHead+height*0.43, LEFT+height*1.16, topHead+height*0.50);
        UI.resetLineWidth();
    }

    /** Draw a car */
    public void drawCar(){
        UI.clearGraphics();
        double width = 200;
        double height = width*0.6;
        double wheel = width/4.5;
        UI.setColor(Color.blue);
        UI.drawRect(LEFT,TOP+height/2, width, height/2);                 // main body of the car
        UI.drawLine(LEFT+width*2.2/5,TOP, LEFT+width*2.2/5,TOP+height);  // vertical division between front and back
        UI.drawLine(LEFT+width/4, TOP, LEFT+width*3/4, TOP);             // top of the roof
        UI.drawLine(LEFT+width/6, TOP+height/2, LEFT+width/4, TOP);      // screens
        UI.drawLine(LEFT+width*5/6, TOP+height/2, LEFT+width*3/4, TOP);
        UI.fillOval(LEFT+width/6-wheel/2.0, TOP+height-wheel/2.0, wheel, wheel);   // wheels
        UI.fillOval(LEFT+width*5/6-wheel/2.0, TOP+height-wheel/2.0, wheel, wheel);
    }

    /** Draw a TV */
    public void drawTV(){
        UI.clearGraphics();
        double width = 200;
        double height = width*0.7;
        double smallWidth = width*0.9;
        double smallHeight = height*0.8;
        UI.drawRect(LEFT,TOP, width, height);
        UI.drawRect(LEFT+(width-smallWidth)/2,TOP+height*0.05, smallWidth, smallHeight);
        double buttonsDiam = height/20;
        double topButtons = TOP+height*0.9;//-(width-smallWidth)/4-buttonsDiam/2;
        UI.fillOval(LEFT+width*0.80, topButtons, buttonsDiam, buttonsDiam);
        UI.fillOval(LEFT+width*0.85, topButtons,buttonsDiam, buttonsDiam);
        UI.drawRect(LEFT+width*0.1, TOP-width*0.1, width*0.2, width*0.1);
        UI.drawLine(LEFT, TOP-height*0.6, LEFT+width*0.20, TOP-width*0.1);
        UI.drawLine(LEFT+width*0.3, TOP-height*0.5, LEFT+width*0.20, TOP-width*0.1);
    }

    public void setupGUI(){
        UI.initialise();
        UI.addButton("Clear", UI::clearPanes );
        UI.addButton("validHour", this::validHour);
        UI.addButton("wordGame", this::wordGame);
        UI.addButton("drawAShape", this::drawAShape);
        UI.addButton("longestWord", this::longestWord);
        UI.addButton("Quit", UI::quit );
        UI.setDivider(0.3);
    }    

    public static void main(String[] args){
        ConditionalsExercise ce = new ConditionalsExercise();
        ce.setupGUI();
    }    

}
